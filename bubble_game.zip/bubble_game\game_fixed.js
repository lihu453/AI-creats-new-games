// 游戏核心逻辑
class BubbleGame {
    constructor() {
        // 获取DOM元素并进行错误检查
        this.gameArea = document.getElementById('game-area');
        this.scoreElement = document.getElementById('score');
        this.timerElement = document.getElementById('timer');
        this.gameOverElement = document.getElementById('game-over');
        this.finalScoreElement = document.getElementById('final-score');
        this.startBtn = document.getElementById('start-btn');
        this.pauseBtn = document.getElementById('pause-btn');
        this.restartBtn = document.getElementById('restart-btn');
        this.playAgainBtn = document.getElementById('play-again-btn');
        
        // 检查必要的DOM元素是否存在
        if (!this.gameArea || !this.scoreElement || !this.timerElement) {
            console.error('游戏核心元素未找到，游戏无法初始化');
            return;
        }
        
        // 游戏状态
        this.score = 0;
        this.timeLeft = 34;
        this.gameInterval = null;
        this.spawnInterval = null;
        this.isPlaying = false;
        this.isPaused = false;
        this.bubbleCount = 0;
        this.maxBubbles = 30; // 增加最大气泡数量
        
        // 分数历史记录
        this.scoreHistory = this.loadScoreHistory();
        this.maxHistoryRecords = 20;
        
        // 气泡配置
        this.bubbleTypes = [
            { className: 'bubble-red', score: 5, size: 40 },
            { className: 'bubble-blue', score: 10, size: 35 },
            { className: 'bubble-green', score: 15, size: 30 },
            { className: 'bubble-yellow', score: 34, size: 25 },
            { className: 'bubble-purple', score: 45, size: 20 }
        ];
        
        // 添加触摸设备支持标志
        this.isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        
        // 初始化事件监听
        this.initEventListeners();
        
        // 添加窗口大小变化监听器以支持响应式调整
        window.addEventListener('resize', () => this.handleResize());
    }
    
    // 初始化事件监听器
    initEventListeners() {
        // 开始按钮事件
        if (this.startBtn) {
            this.startBtn.addEventListener('click', () => this.startGame());
        }
        
        // 暂停按钮事件
        if (this.pauseBtn) {
            this.pauseBtn.addEventListener('click', () => this.pauseGame());
        }
        
        // 重新开始按钮事件
        if (this.restartBtn) {
            this.restartBtn.addEventListener('click', () => this.restartGame());
        }
        
        // 再玩一次按钮事件
        if (this.playAgainBtn) {
            this.playAgainBtn.addEventListener('click', () => this.restartGame());
        }
        
        // 分数历史按钮事件
        const historyBtn = document.getElementById('history-btn');
        if (historyBtn) {
            historyBtn.addEventListener('click', () => this.showScoreHistory());
        }
        
        // 游戏结束界面中的查看历史记录按钮
        const viewHistoryBtn = document.getElementById('view-history-btn');
        if (viewHistoryBtn) {
            viewHistoryBtn.addEventListener('click', () => {
                // 先隐藏游戏结束界面
                if (this.gameOverElement) {
                    this.gameOverElement.classList.add('hidden');
                }
                // 再显示分数历史
                this.showScoreHistory();
            });
        }
        
        // 关闭分数历史按钮
        const closeHistoryBtn = document.getElementById('close-history-btn');
        if (closeHistoryBtn) {
            closeHistoryBtn.addEventListener('click', () => this.hideScoreHistory());
        }
        
        // 清除分数历史按钮
        const clearHistoryBtn = document.getElementById('clear-history-btn');
        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener('click', () => this.clearScoreHistory());
        }
        
        // 创建教程按钮
        this.createTutorialButton();
    }
    
    // 创建游戏教程按钮
    createTutorialButton() {
        const tutorialBtn = document.createElement('button');
        tutorialBtn.textContent = '游戏教程';
        tutorialBtn.className = 'control-btn';
        tutorialBtn.style.marginLeft = '10px';
        
        // 查找游戏控制按钮容器并添加教程按钮
        const controlsContainer = document.querySelector('.game-controls');
        if (controlsContainer) {
            controlsContainer.appendChild(tutorialBtn);
        }
        
        // 添加点击事件
        tutorialBtn.addEventListener('click', () => this.showTutorial());
    }
    
    // 开始游戏
    startGame() {
        if (this.isPlaying) return;
        
        this.isPlaying = true;
        this.isPaused = false;
        
        // 更新按钮状态
        if (this.startBtn) this.startBtn.disabled = true;
        if (this.pauseBtn) this.pauseBtn.disabled = false;
        if (this.restartBtn) this.restartBtn.disabled = false;
        
        // 隐藏游戏结束界面
        if (this.gameOverElement) {
            this.gameOverElement.classList.add('hidden');
        }
        
        // 开始计时器
        this.startTimer();
        
        // 开始生成气泡 - 缩短生成间隔
        this.spawnInterval = setInterval(() => this.spawnBubble(), 400);
    }
    
    // 暂停游戏
    pauseGame() {
        if (!this.isPlaying) return;
        
        if (!this.isPaused) {
            // 暂停游戏
            this.isPaused = true;
            if (this.pauseBtn) this.pauseBtn.textContent = '继续';
            
            // 停止计时器
            if (this.gameInterval) {
                clearInterval(this.gameInterval);
                this.gameInterval = null;
            }
            
            // 停止生成气泡
            if (this.spawnInterval) {
                clearInterval(this.spawnInterval);
                this.spawnInterval = null;
            }
        } else {
            // 继续游戏
            this.isPaused = false;
            if (this.pauseBtn) this.pauseBtn.textContent = '暂停';
            
            // 继续计时器
            this.startTimer();
            
            // 继续生成气泡 - 缩短生成间隔
            this.spawnInterval = setInterval(() => this.spawnBubble(), 400);
        }
    }
    
    // 重新开始游戏
    restartGame() {
        // 停止所有计时器
        if (this.gameInterval) {
            clearInterval(this.gameInterval);
            this.gameInterval = null;
        }
        if (this.spawnInterval) {
            clearInterval(this.spawnInterval);
            this.spawnInterval = null;
        }
        
        // 重置游戏状态
        this.score = 0;
        this.timeLeft = 34;
        this.isPlaying = false;
        this.isPaused = false;
        
        // 更新UI
        if (this.scoreElement) this.scoreElement.textContent = '0';
        if (this.timerElement) this.timerElement.textContent = '34';
        
        // 更新按钮状态
        if (this.startBtn) this.startBtn.disabled = false;
        if (this.pauseBtn) {
            this.pauseBtn.disabled = true;
            this.pauseBtn.textContent = '暂停';
        }
        if (this.restartBtn) this.restartBtn.disabled = true;
        
        // 隐藏游戏结束界面
        if (this.gameOverElement) {
            this.gameOverElement.classList.add('hidden');
        }
        
        // 清除所有气泡
        this.clearBubbles();
    }
    
    // 开始计时器
    startTimer() {
        this.gameInterval = setInterval(() => {
            this.timeLeft--;
            if (this.timerElement) {
                this.timerElement.textContent = this.timeLeft;
            }
            
            // 时间到，游戏结束
            if (this.timeLeft <= 0) {
                this.endGame();
            }
        }, 1000);
    }
    
    // 游戏结束
    endGame() {
        this.isPlaying = false;
        
        // 停止所有计时器
        if (this.gameInterval) {
            clearInterval(this.gameInterval);
            this.gameInterval = null;
        }
        if (this.spawnInterval) {
            clearInterval(this.spawnInterval);
            this.spawnInterval = null;
        }
        
        // 更新按钮状态
        if (this.startBtn) this.startBtn.disabled = true;
        if (this.pauseBtn) this.pauseBtn.disabled = true;
        if (this.restartBtn) this.restartBtn.disabled = true;
        
        // 显示游戏结束界面
        if (this.gameOverElement) {
            this.gameOverElement.classList.remove('hidden');
        }
        
        // 显示最终得分
        if (this.finalScoreElement) {
            this.finalScoreElement.textContent = this.score;
        }
        
        // 保存当前游戏分数到历史记录
        this.saveScoreToHistory(this.score);
        
        // 清除所有气泡
        this.clearBubbles();
    }
    
    // 处理窗口大小变化
    handleResize() {
        // 调整游戏区域中的气泡位置，避免超出边界
        const bubbles = document.querySelectorAll('.bubble');
        bubbles.forEach(bubble => {
            const size = parseInt(bubble.style.width);
            const maxLeft = this.gameArea.clientWidth - size;
            const currentLeft = parseInt(bubble.style.left);
            
            if (currentLeft > maxLeft) {
                bubble.style.left = `${maxLeft}px`;
            }
        });
    }
    
    // 生成气泡
    spawnBubble() {
        if (!this.isPlaying || this.isPaused || this.bubbleCount >= this.maxBubbles) return;
        
        // 随机选择气泡类型
        const bubbleType = this.bubbleTypes[Math.floor(Math.random() * this.bubbleTypes.length)];
        
        try {
            // 创建气泡元素
            const bubble = document.createElement('div');
            bubble.classList.add('bubble', bubbleType.className);
            
            // 设置气泡大小
            const size = bubbleType.size;
            bubble.style.width = `${size}px`;
            bubble.style.height = `${size}px`;
            
            // 设置气泡位置
            const maxLeft = this.gameArea.clientWidth - size;
            bubble.style.left = `${Math.random() * maxLeft}px`;
            bubble.style.bottom = `-50px`;
            
            // 设置气泡分值
            bubble.dataset.score = bubbleType.score;
            
            // 添加事件处理 - 支持触摸和鼠标
            const eventType = this.isTouchDevice ? 'touchstart' : 'click';
            bubble.addEventListener(eventType, (e) => {
                e.preventDefault(); // 阻止触摸事件的默认行为
                this.popBubble(bubble);
            }, { passive: false });
            
            // 添加气泡消失事件
            bubble.addEventListener('animationend', () => {
                this.bubbleCount--;
                if (bubble.parentNode) {
                    bubble.parentNode.removeChild(bubble);
                }
            });
            
            // 添加到游戏区域
            this.gameArea.appendChild(bubble);
            this.bubbleCount++;
            
            // 设置随机动画持续时间 - 调整为3-8秒，增加移速
            const duration = 3 + Math.random() * 5;
            bubble.style.animation = `floatUp ${duration}s ease-in forwards`;
        } catch (error) {
            console.warn('生成气泡时出错:', error);
        }
    }
    
    // 点击气泡并弹出
    popBubble(bubble) {
        if (!this.isPlaying || this.isPaused || !bubble || bubble.classList.contains('popping')) return;
        
        // 标记气泡为正在弹出，防止重复点击
        bubble.classList.add('popping');
        
        try {
            // 停止原动画
            bubble.style.animation = 'none';
            
            // 播放弹出动画
            bubble.style.animation = 'pop 0.3s ease-out forwards';
            
            // 增加分数
            const points = parseInt(bubble.dataset.score) || 5;
            this.score += points;
            this.scoreElement.textContent = this.score;
            
            // 添加分数变化的视觉反馈
            this.scoreElement.style.animation = 'scoreChange 0.3s ease-out';
            setTimeout(() => {
                this.scoreElement.style.animation = 'none';
            }, 300);
            
            // 播放点击音效
            this.playSound('click');
            
            // 显示分数反馈
            this.showScoreFeedback(bubble, points);
            
            // 移除气泡
            setTimeout(() => {
                this.bubbleCount--;
                if (bubble.parentNode) {
                    bubble.parentNode.removeChild(bubble);
                }
            }, 300);
        } catch (error) {
            console.warn('处理气泡点击时出错:', error);
            // 确保气泡计数正确
            this.bubbleCount = Math.max(0, this.bubbleCount - 1);
        }
    }
    
    // 显示分数反馈
    showScoreFeedback(bubble, points) {
        const feedback = document.createElement('div');
        feedback.textContent = `+${points}`;
        feedback.style.cssText = `
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            font-size: 1.2em;
            font-weight: bold;
            color: #fff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            pointer-events: none;
            z-index: 10;
            animation: scoreFloatUp 1s ease-out forwards;
        `;
        
        // 添加动画样式
        const style = document.createElement('style');
        style.textContent = `
            @keyframes scoreFloatUp {
                0% {
                    opacity: 1;
                    transform: translate(-50%, -50%) scale(1);
                }
                50% {
                    opacity: 1;
                    transform: translate(-50%, -100%) scale(1.2);
                }
                100% {
                    opacity: 0;
                    transform: translate(-50%, -200%) scale(1);
                }
            }
        `;
        document.head.appendChild(style);
        
        // 将反馈元素添加到游戏区域
        this.gameArea.appendChild(feedback);
        
        // 设置反馈元素位置为气泡位置
        const bubbleRect = bubble.getBoundingClientRect();
        const gameAreaRect = this.gameArea.getBoundingClientRect();
        
        feedback.style.left = `${bubbleRect.left - gameAreaRect.left + bubbleRect.width / 2}px`;
        feedback.style.top = `${bubbleRect.top - gameAreaRect.top + bubbleRect.height / 2}px`;
        
        // 1秒后移除反馈元素
        setTimeout(() => {
            if (feedback.parentNode) {
                feedback.parentNode.removeChild(feedback);
            }
        }, 1000);
    }
    
    // 播放音效
    playSound(type) {
        try {
            // 创建音频上下文
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            const audioCtx = new AudioContext();
            
            // 创建振荡器
            const oscillator = audioCtx.createOscillator();
            const gainNode = audioCtx.createGain();
            
            // 根据类型设置不同的音效
            if (type === 'click') {
                oscillator.type = 'sine';
                oscillator.frequency.value = 800 + Math.random() * 400;
                gainNode.gain.value = 0.1;
                
                // 创建快速的音量衰减
                gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
                
                // 连接节点
                oscillator.connect(gainNode);
                gainNode.connect(audioCtx.destination);
                
                // 播放声音
                oscillator.start(audioCtx.currentTime);
                oscillator.stop(audioCtx.currentTime + 0.2);
            }
        } catch (error) {
            // 如果浏览器不支持Web Audio API，忽略错误
            console.warn('无法播放音效:', error);
        }
    }
    
    // 清除所有气泡
    clearBubbles() {
        const bubbles = document.querySelectorAll('.bubble');
        bubbles.forEach(bubble => {
            if (bubble.parentNode) {
                bubble.parentNode.removeChild(bubble);
            }
        });
        this.bubbleCount = 0;
    }
    
    // 显示游戏教程
    showTutorial() {
        // 检查是否已有教程元素
        let tutorialElement = document.querySelector('.game-tutorial');
        
        if (!tutorialElement) {
            // 创建教程元素
            tutorialElement = document.createElement('div');
            tutorialElement.className = 'game-tutorial';
            tutorialElement.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: rgba(255, 255, 255, 0.95);
                border-radius: 15px;
                padding: 30px;
                max-width: 80%;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
                z-index: 1000;
                animation: fadeIn 0.3s ease-out;
            `;
            
            // 添加教程内容
            tutorialElement.innerHTML = `
                <h3>🎮 游戏教程</h3>
                <p>欢迎来到气泡点击游戏！通过点击各种颜色的气泡来获取高分。</p>
                <h4>游戏目标</h4>
                <p>在34秒内尽可能多地点击气泡，获取最高分数！</p>
                <h4>游戏规则</h4>
                <ol>
                    <li>点击屏幕上出现的气泡来获得分数</li>
                    <li><strong style="color: #e74c3c;">红色气泡</strong> - 5分</li>
                    <li><strong style="color: #3498db;">蓝色气泡</strong> - 10分</li>
                    <li><strong style="color: #2ecc71;">绿色气泡</strong> - 15分</li>
                    <li><strong style="color: #f39c12;">黄色气泡</strong> - 34分</li>
                    <li><strong style="color: #9b59b6;">紫色气泡</strong> - 45分</li>
                    <li>游戏时间为34秒，时间结束后显示最终得分</li>
                </ol>
                <h4>操作说明</h4>
                <ul>
                    <li><strong>开始游戏</strong> - 点击"开始游戏"按钮开始挑战</li>
                    <li><strong>暂停/继续</strong> - 游戏中可以暂停或继续游戏</li>
                    <li><strong>重新开始</strong> - 随时可以重新开始游戏</li>
                    <li><strong>键盘快捷键</strong>：空格键或回车键(开始/暂停)，R键(重新开始)，H键(显示帮助)</li>
                </ul>
                <button id="close-tutorial" style="
                    background: #3498db;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 1rem;
                    font-weight: bold;
                    transition: background-color 0.3s;
                ">明白了，开始游戏！</button>
            `;
            
            // 添加到文档中
            document.body.appendChild(tutorialElement);
            
            // 添加关闭按钮事件
            const closeBtn = tutorialElement.querySelector('#close-tutorial');
            closeBtn.addEventListener('click', () => this.hideTutorial());
            
            // 添加点击外部关闭功能
            tutorialElement.addEventListener('click', (e) => {
                if (e.target === tutorialElement) {
                    this.hideTutorial();
                }
            });
        } else {
            // 显示已有的教程元素
            tutorialElement.style.display = 'block';
            tutorialElement.style.animation = 'fadeIn 0.3s ease-out';
        }
    }
    
    // 隐藏游戏教程
    hideTutorial() {
        const tutorialElement = document.querySelector('.game-tutorial');
        if (tutorialElement) {
            tutorialElement.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => {
                tutorialElement.style.display = 'none';
            }, 300);
        }
    }
    
    // 从localStorage加载分数历史记录
    loadScoreHistory() {
        try {
            const savedHistory = localStorage.getItem('bubbleGameScoreHistory');
            return savedHistory ? JSON.parse(savedHistory) : [];
        } catch (error) {
            console.warn('加载分数历史失败:', error);
            return [];
        }
    }
    
    // 保存分数历史记录到localStorage
    saveScoreHistory() {
        try {
            localStorage.setItem('bubbleGameScoreHistory', JSON.stringify(this.scoreHistory));
        } catch (error) {
            console.warn('保存分数历史失败:', error);
        }
    }
    
    // 将当前分数添加到历史记录
    saveScoreToHistory(score) {
        // 创建新的分数记录
        const scoreRecord = {
            score: score,
            timestamp: new Date().toISOString(),
            date: this.formatDate(new Date())
        };
        
        // 添加到历史记录数组
        this.scoreHistory.push(scoreRecord);
        
        // 按分数降序排序
        this.scoreHistory.sort((a, b) => b.score - a.score);
        
        // 限制历史记录数量
        if (this.scoreHistory.length > this.maxHistoryRecords) {
            this.scoreHistory = this.scoreHistory.slice(0, this.maxHistoryRecords);
        }
        
        // 为每条记录添加排名
        this.scoreHistory.forEach((record, index) => {
            record.rank = index + 1;
        });
        
        // 保存到localStorage
        this.saveScoreHistory();
    }
    
    // 格式化日期显示
    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }
    
    // 显示分数历史记录
    showScoreHistory() {
        const historyElement = document.getElementById('score-history');
        const tableBody = document.querySelector('#history-table tbody');
        const noHistoryElement = document.getElementById('no-history');
        const averageScoreElement = document.getElementById('average-score');
        
        if (!historyElement || !tableBody) return;
        
        // 清空表格
        tableBody.innerHTML = '';
        
        // 检查是否有历史记录
        if (this.scoreHistory.length === 0) {
            if (noHistoryElement) {
                noHistoryElement.classList.remove('hidden');
            }
            // 设置平均分为0
            if (averageScoreElement) {
                averageScoreElement.textContent = '0';
            }
        } else {
            if (noHistoryElement) {
                noHistoryElement.classList.add('hidden');
            }
            
            // 计算平均分
            const totalScore = this.scoreHistory.reduce((sum, record) => sum + record.score, 0);
            const averageScore = Math.round(totalScore / this.scoreHistory.length);
            if (averageScoreElement) {
                averageScoreElement.textContent = averageScore;
            }
            
            // 填充表格
            this.scoreHistory.forEach(record => {
                const row = document.createElement('tr');
                
                // 排名单元格 - 前三名有特殊样式
                const rankCell = document.createElement('td');
                rankCell.textContent = record.rank;
                if (record.rank === 1) rankCell.className = 'rank-1';
                else if (record.rank === 2) rankCell.className = 'rank-2';
                else if (record.rank === 3) rankCell.className = 'rank-3';
                row.appendChild(rankCell);
                
                // 分数单元格
                const scoreCell = document.createElement('td');
                scoreCell.textContent = record.score;
                scoreCell.className = 'score-cell';
                row.appendChild(scoreCell);
                
                // 时间单元格
                const dateCell = document.createElement('td');
                dateCell.textContent = record.date;
                row.appendChild(dateCell);
                
                tableBody.appendChild(row);
            });
        }
        
        // 显示历史记录界面
        historyElement.classList.remove('hidden');
    }
    
    // 隐藏分数历史记录
    hideScoreHistory() {
        const historyElement = document.getElementById('score-history');
        if (historyElement) {
            historyElement.classList.add('hidden');
        }
    }
    
    // 清除分数历史记录
    clearScoreHistory() {
        if (confirm('确定要清除所有分数历史记录吗？')) {
            this.scoreHistory = [];
            this.saveScoreHistory();
            this.showScoreHistory(); // 更新显示
        }
    }
}

// 添加游戏优化样式
const addGameStyles = () => {
    const style = document.createElement('style');
    style.textContent = `
        /* 教程动画 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: translateY(0);
            }
            to {
                opacity: 0;
                transform: translateY(-20px);
            }
        }
        
        /* 分数变化动画 */
        @keyframes scoreChange {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); color: #e74c3c; }
            100% { transform: scale(1); }
        }
        
        /* 教程样式 */
        .game-tutorial {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 25px;
            margin-top: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .game-tutorial h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 1.3rem;
        }
        
        .game-tutorial p {
            color: #555;
            margin-bottom: 15px;
            line-height: 1.6;
        }
        
        .game-tutorial ol {
            padding-left: 25px;
            margin-bottom: 20px;
        }
        
        .game-tutorial li {
            padding: 5px 0;
            color: #555;
            line-height: 1.5;
        }
        
        /* 优化触摸设备体验 */
        @media (hover: none) and (pointer: coarse) {
            .bubble:hover {
                transform: none; /* 移除触摸设备上的悬停效果 */
            }
            
            .control-btn {
                padding: 15px 28px; /* 增大触摸目标 */
                font-size: 1.1rem;
            }
        }
        
        /* 性能优化 - 硬件加速 */
        .bubble {
            transform: translateZ(0);
            will-change: transform, opacity;
        }
        
        /* 防止文本选择 */
        .game-area {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-tap-highlight-color: transparent; /* 移除移动设备点击高亮 */
        }
    `;
    document.head.appendChild(style);
};

// 当页面加载完成后初始化游戏
window.addEventListener('DOMContentLoaded', () => {
    try {
        // 添加游戏样式
        addGameStyles();
        
        // 检查是否存在必要的DOM元素
        if (document.getElementById('game-area')) {
            const game = new BubbleGame();
            window.bubbleGameInstance = game;
            
            // 延迟显示教程提示
            setTimeout(() => {
                if (game && typeof game.showTutorial === 'function') {
                    game.showTutorial();
                }
            }, 2000);
            
            // 添加键盘快捷键支持
            document.addEventListener('keydown', (e) => {
                if (!game) return;
                
                switch (e.key.toLowerCase()) {
                    case ' ': // 空格键开始/暂停
                    case 'enter':
                        e.preventDefault();
                        if (!game.isPlaying) {
                            if (game.startGame) game.startGame();
                        } else if (game.pauseGame) {
                            game.pauseGame();
                        }
                        break;
                    case 'r': // R键重新开始
                        e.preventDefault();
                        if (game.restartGame) game.restartGame();
                        break;
                    case 'h': // H键显示帮助
                        e.preventDefault();
                        if (game.showTutorial) game.showTutorial();
                        break;
                }
            });
        }
    } catch (error) {
        console.error('游戏初始化出错:', error);
        // 显示用户友好的错误消息
        const errorMessage = document.createElement('div');
        errorMessage.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #e74c3c;
            color: white;
            padding: 20px;
            border-radius: 10px;
            z-index: 1000;
            text-align: center;
            max-width: 90%;
        `;
        errorMessage.innerHTML = `
            <h3>游戏加载失败</h3>
            <p>请尝试刷新页面或检查您的浏览器设置。</p>
            <button onclick="window.location.reload()" style="
                margin-top: 10px;
                padding: 8px 16px;
                background: white;
                color: #e74c3c;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
            ">刷新页面</button>
        `;
        document.body.appendChild(errorMessage);
    }
});

// 页面卸载时清理资源
window.addEventListener('beforeunload', () => {
    // 清理定时器和事件监听器，防止内存泄漏
    const game = window.bubbleGameInstance;
    if (game) {
        if (game.clearBubbles) game.clearBubbles();
        if (game.gameInterval) clearInterval(game.gameInterval);
        if (game.spawnInterval) clearInterval(game.spawnInterval);
    }
});